"use strict";

var transList = [];
const TransactionType = { Deposit: "deposit", WithDrawal: "withdrawal" };

var getTransaction = function (index) {
  if (typeof index === "undefined") {
    return transList.length;
  }
  return transList[index];
};

var addTransaction = function (type, amount, date) {
  let transactionObj = {
    type: type,
    amount: amount,
    date: date,
  };

  date = !date ? new Date() : new Date(date);

  //format displays
  transactionObj.dateDisplay = formatDate(date);
  transactionObj.amountDisplay =
    type == TransactionType.WithDrawal ? `(${amount})` : amount;

  transList.push(transactionObj);

  return transactionObj;
};

var calculateBalance = function (type, amount, total) {
  total = parseFloat(total);
  amount = parseFloat(amount);

  if (type == TransactionType.Deposit) {
    return total + amount;
  }

  if (type == TransactionType.WithDrawal) {
    return total - amount;
  }

  return total;
};

var formatDate = function (date) {
  date = date.toDateString();
  return date.substr(date.indexOf(" ") + 1);
};
