var $ = function(id) {
    return document.getElementById(id);
};

var $ = function(id) {
    return document.getElementById(id);
};

var processEntry = function() {
	var entry = $("cents").value;         // get user entry
	var cents = parseInt(entry);          // parse entry

	if (isNaN(cents) || cents < 0 || cents > 99){
		alert("Please Enter a valid value");
		return
	}

	makeChange(cents);
	$("cents").focus();
};

var makeChange = function(cents) {
	var quarters = parseInt(cents / 25); // get number of quarters
	cents %= 25;

	var dimes = parseInt(cents / 10); // get number of dimes  
	cents %= 10;

	var nickels = parseInt(cents / 5); // get number of nickels
	cents %= 5;

	var pennies = parseInt(cents / 1); // get number of pennies
	
	// display the results of the calculations
	$("quarters").value = quarters;
	$("dimes").value = dimes;
	$("nickels").value = nickels;
	$("pennies").value = pennies;
};

window.onload = function () {
    $("calculate").onclick = processEntry;
	$("cents").focus();
};
