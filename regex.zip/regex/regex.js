"use strict";
var $ = function (id) {
  return document.getElementById(id);
};

var validatePhone = function () {
  var phone = $("phone").value;
  //var pattern = /^\d{3}-\d{3}-\d{4}$/; // 999-999-9999
  //var pattern = /^(\d{1}-)?\d{3}-\d{3}-\d{4}$/; //1-123-456-7890 optional leading 1
  //var pattern = /^(\d{1}[-.])?\d{3}[-.]\d{3}[-.]\d{4}$/; //1.123.456-7890 dashes or periods
  var pattern = /^(\d{1}[.-])?((\d{1}\s?)(\(\d{3}\)\s?)|(\d{3})[.-])(\d{3}[.-])(\d{4})$/; //optional parentheses around the area code with/without whitespace
  var isValid = pattern.test(phone);

  $("message").firstChild.nodeValue = isValid
    ? "Valid phone number"
    : "Invalid phone number";
};

window.onload = function () {
  $("validate").onclick = validatePhone;
  $("phone").value = "123-456-7890"; // set default phone number
};
