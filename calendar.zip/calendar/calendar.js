const $ = function (id) { return document.getElementById(id); };

const getMonthText = function(currentMonth) {
    if (currentMonth === 0) { return "January"; }
    else if (currentMonth === 1) { return "February"; }
    else if (currentMonth === 2) { return "March"; }
    else if (currentMonth === 3) { return "April"; }
    else if (currentMonth === 4) { return "May"; }
    else if (currentMonth === 5) { return "June"; }
    else if (currentMonth === 6) { return "July"; }
    else if (currentMonth === 7) { return "August"; }
    else if (currentMonth === 8) { return "September"; }
    else if (currentMonth === 9) { return "October"; }
    else if (currentMonth === 10) { return "November"; }
    else if (currentMonth === 11) { return "December"; }
};

const getLastDayofMonth = function(dateObj) {
    return new Date(dateObj.getFullYear(), dateObj.getMonth()+1, 0).getDate();
};

const insertCellData = function(tableRow, cellIndex, cellValue) {
    const tableData = tableRow.insertCell(cellIndex);
    tableData.innerHTML = cellValue;
}

window.onload = function () {
    const date = new Date();
    $("month_year").innerHTML = `${getMonthText(date.getMonth())} ${date.getFullYear()}`;
    const firstDayOfMonth = new Date(date.getFullYear(), date.getMonth(), 1);
    const lastDayofMonth = getLastDayofMonth(date);
    const table = $("calendar");
    const maxWeeks = 6;
    const maxDays = 6;
    let currentDay = 1;

    for (let i = 1; i <= maxWeeks; i++) {
        const tableRow = table.insertRow(i);
        for(let j = 0; j <= maxDays; j++) {
            if (currentDay > lastDayofMonth) {
                return;
            }
            if (i == 1 && j != firstDayOfMonth.getDay() && currentDay == 1) {
                //insert empty <td> until first day of month is found
                insertCellData(tableRow, j, "");
                continue;
            } else {
                insertCellData(tableRow, j, currentDay);
                currentDay++;
            }
        }
    }
};
