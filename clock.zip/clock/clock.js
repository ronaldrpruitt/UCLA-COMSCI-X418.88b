"use strict";
var $ = function (id) {
  return document.getElementById(id);
};

var displayCurrentTime = function () {
  const date = new Date();
  $("hours").innerText = getFormatedHours(date);
  $("minutes").innerText = padSingleDigit(date.getMinutes());
  $("seconds").innerText = date.getSeconds();
  $("ampm").innerText = date.getHours() >= 12 ? "PM" : "AM";
};

var padSingleDigit = function (num) {
  return num < 10 ? "0" + num : num;
};
var getFormatedHours = function (date) {
  return date
    .toLocaleString("en-US", {
      hour: "numeric",
      hour12: true,
    })
    .split(" ")[0];
};

window.onload = function () {
  const clock = displayCurrentTime();
  setInterval(function () {
    displayCurrentTime();
  }, 1000);
  // set initial clock display and then set interval timer to display
  // new time every second. Don't store timer object because it
  // won't be needed - clock will just run.
};
