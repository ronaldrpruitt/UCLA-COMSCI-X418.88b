"use strict";
(function ($) {
  $.fn.styleTable = function () {
    var elements = document.getElementsByTagName("tr");
    $(elements).filter(":even").addClass("even");
    $(elements).filter(":odd").addClass("odd");
    $(elements).first().addClass("header").removeClass("even");
  };
})(jQuery);
