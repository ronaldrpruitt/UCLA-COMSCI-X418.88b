"use strict";

window.onload = function () {
  $(document).ready(function () {
    $().styleTable();
  });
};
